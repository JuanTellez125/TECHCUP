package edu.dosw.TECHCUP.controller.mapper;

import edu.dosw.TECHCUP.controller.dto.request.InvitationRequestDTO;
import edu.dosw.TECHCUP.controller.dto.response.InvitationResponseDTO;
import edu.dosw.TECHCUP.core.model.Invitation;
import edu.dosw.TECHCUP.persistence.entity.InvitationEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface InvitationMapper {

    @Mapping(source = "invitationId",           target = "id")
    @Mapping(source = "team.id",                target = "teamId")
    @Mapping(source = "team.name",              target = "teamName")
    @Mapping(source = "invitedUser.userId",     target = "invitedUserId")
    @Mapping(source = "invitedUser.firstName",  target = "invitedUserName")
    @Mapping(source = "invitedBy.userId",       target = "invitedById")
    @Mapping(source = "invitedBy.firstName",    target = "invitedByName")
    InvitationResponseDTO toDto(Invitation invitation);

    Invitation toModel(InvitationRequestDTO dto);
}