package edu.dosw.TECHCUP.controller.mapper;

import edu.dosw.TECHCUP.controller.dto.response.TournamentRegistrationResponseDTO;
import edu.dosw.TECHCUP.core.model.TournamentRegistration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TournamentRegistrationMapper {

    @Mapping(source = "TournamentRegistration_id",    target = "id")
    @Mapping(source = "tournament.tournament_id",     target = "tournamentId")
    @Mapping(source = "team.id",                      target = "teamId")
    @Mapping(source = "team.name",                    target = "teamName")
    TournamentRegistrationResponseDTO toDto(TournamentRegistration registration);
}