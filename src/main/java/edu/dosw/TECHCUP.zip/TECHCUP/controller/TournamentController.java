package edu.dosw.TECHCUP.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tournament")
public class TournamentController {

}