package edu.dosw.TECHCUP.controller.dto.response;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineUpResponseDTO {

    private Long id;

    private Long matchId;

    private Long teamId;

    private String teamName;

    private Long userId;

    private String userName;

    private String role;

    private String position;

    private int jerseyNumber;
}