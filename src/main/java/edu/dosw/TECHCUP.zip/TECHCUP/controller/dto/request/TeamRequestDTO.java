package edu.dosw.TECHCUP.controller.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TeamRequestDTO {

    @NotBlank(message = "El nombre del equipo no puede estar vacío")
    private String name;

    private String shieldUrl;

    private String mainColor;

    private String secondaryColor;
}