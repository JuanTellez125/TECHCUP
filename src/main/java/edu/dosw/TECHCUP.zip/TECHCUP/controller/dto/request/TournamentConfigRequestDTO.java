package edu.dosw.TECHCUP.controller.dto.request;

import lombok.*;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TournamentConfigRequestDTO {

    private String rulebook;

    private LocalDate inscriptionDeadline;

    private String schedules;

    private String sanctions;
}