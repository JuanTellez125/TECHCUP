package edu.dosw.TECHCUP.core.validator;

public class TeamValidator {
}
