package edu.dosw.TECHCUP.core.service;

import edu.dosw.TECHCUP.controller.dto.request.TournamentRequestDTO;
import edu.dosw.TECHCUP.controller.dto.response.TournamentResponseDTO;
import edu.dosw.TECHCUP.core.exception.TournamentValidationException;
import edu.dosw.TECHCUP.core.model.enums.Role;
import edu.dosw.TECHCUP.core.model.Tournament;
import edu.dosw.TECHCUP.core.model.User;
import edu.dosw.TECHCUP.core.repository.TournamentRepository;
import org.springframework.stereotype.Service;
import edu.dosw.TECHCUP.core.exception.UserNotFoundException;
import edu.dosw.TECHCUP.core.repository.UserRepository;
import edu.dosw.TECHCUP.controller.mapper.TournamentMapper;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TournamentService {


    private final TournamentRepository tournamentRepository;
    private final TournamentMapper tournamentMapper;
    private final UserRepository userRepository;

    public TournamentResponseDTO createTournament(String organizerId, TournamentRequestDTO dto) {

        User user = userRepository.findById(organizerId)
                .orElseThrow(() -> new UserNotFoundException("User Must Be Organizer"));

        if (!user.getRole().equals(String.valueOf(Role.ORGANIZER))) {
             throw new TournamentValidationException("The user does not have permissions to create the tournament");
        }

        Tournament tournament = Tournament.builder()
                    .organizerId(organizerId)
                    .build();

        return null;
        
    }
}