package edu.dosw.TECHCUP.core.service;

import edu.dosw.TECHCUP.controller.mapper.MatchMapper;
import edu.dosw.TECHCUP.core.repository.MatchRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MatchService {

    private final MatchRepository matchRepository;
    private final MatchMapper matchMapper;

}
